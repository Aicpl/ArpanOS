PASSWORD FOR EVERYTHING � 1647

This is ArpanOS V-1.0.5.0
This OS is fully compatible with x64 windows versions.
Maker-Arpan Chatterjee
This is my first OS!
No bugs. It has passed my quality checks. I have checked it and I did not find any bugs. Bugs will only appear if the system crashes, gets corrupt or by your mistake. I have tried my best to make it user-friendly. It uses MS-DOS like commands, but not that hard to remember. I have included the .BAS file of the OS, so that you all can configure it independently. I made it using QB64, and the .BAS file will open in QB64 only! You can inform to me anything about this OS by mailing me at -arpanchatterjee1647@gmail.com .I will give more updates and include more programs in the next update. 
Password for all apps � 1647
Font used � arpanosbitmap.ttf (Microsoft� TrueType font)
Language � English
Source code - .BAS
Please do not change the ArpanOS source code. It is only for reference and copying.
Programs included:-
1) Plotter <plotter> 
 2) Converter <converter>  
 3) Calculator <calculator>
 4) Multiplication table maker <tables> 
 5) Area and Perimeter finder <finder> 
 6) Clock (24-hour format) <clock> 
 7) Picture viewer <picviewer> 
 8) Text editor  
 9) Music player
10) Stopwatch with alarm

Files in this pack:-
1) ArpanOS README File (This file)
2) ARPAN_OS.EXE (Operating system executable file (OPEN THIS FIRST!)
3) ARPAN_OS.BAS (Source code file)
4) Arpanosbitmap.ttf (Fonts file) 

Good luck!
By - Arpan Chatterjee
Run the program to see the programs included in the OS.
Please run the .EXE file first!
Note � This program does not add any files to your computer except the files you have downloaded.


